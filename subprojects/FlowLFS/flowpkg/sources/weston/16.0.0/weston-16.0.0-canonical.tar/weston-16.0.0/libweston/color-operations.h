/*
 * Copyright 2025-2026 Collabora, Ltd.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice (including the
 * next paragraph) shall be included in all copies or substantial
 * portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT.  IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#ifndef WESTON_COLOR_OPERATIONS_H
#define WESTON_COLOR_OPERATIONS_H

#include <libweston/libweston.h>
#include <libweston/linalg-3.h>

#include "color.h"

void
weston_color_curve_sample(struct weston_compositor *compositor,
			  const struct weston_color_curve *curve,
			  const struct weston_vec3f *in,
			  struct weston_vec3f *out,
			  size_t len);

const struct weston_color_curve *
weston_color_transform_as_single_curve(const struct weston_color_transform *xform);

struct weston_color_curve *
weston_color_curve_create_inverse(const struct weston_color_curve *curve);

#endif /* WESTON_COLOR_OPERATIONS_H */
