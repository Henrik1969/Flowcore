# Security Reporting

If you wish to report a security vulnerability privately, we appreciate your diligence. Please follow the guidelines below to submit your report.

## Reporting

To report a security vulnerability, please provide the following information:

1. **PROJECT**
   - Include the URL of the project repository - Example: <https://github.com/sharkdp/fd>

2. **PUBLIC**
   - Indicate whether this vulnerability has already been publicly discussed or disclosed.
   - If so, provide relevant links.

3. **DESCRIPTION**
   - Provide a detailed description of the security vulnerability.
   - Include as much information as possible to help us understand and address the issue.

Send this information, along with any additional relevant details, to our [vulnerability reporting form](https://github.com/sharkdp/fd/security/advisories/new).

## Confidentiality

We kindly ask you to keep the report confidential until a public announcement is made.

## Notes

- Vulnerabilities will be handled on a best-effort basis.
- You may request an advance copy of the patched release, but we cannot guarantee early access before the public release.
- You will be notified via email simultaneously with the public announcement.
- We will respond within a few weeks to confirm whether your report has been accepted or rejected.

Thank you for helping to improve the security of our project!
